package com.example.krok

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.WindowManager
import java.util.Locale

/**
 * Фоновая служба Крока:
 * 1. слушает и ждёт фразу «Привет, Крок»;
 * 2. после неё слушает команду (или берёт её из той же фразы);
 * 3. показывает круглый значок, который меняет цвет и лицо;
 * 4. отвечает голосом.
 */
class ListeningService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var windowManager: WindowManager
    private lateinit var face: KrokView
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var waitingForCommand = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        showFace()
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale("ru")
        }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(listener)
        }
        listen()
    }

    // ---------- Значок поверх экрана ----------

    private fun showFace() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        face = KrokView(this)
        val size = (96 * resources.displayMetrics.density).toInt()
        val params = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 24
            y = 200
        }
        windowManager.addView(face, params)
    }

    // ---------- Слух ----------

    private fun listen() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
        }
        recognizer?.startListening(intent)
    }

    private val listener = object : RecognitionListener {

        override fun onResults(results: Bundle?) {
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                ?.lowercase(Locale("ru"))
                ?.replace(",", "")
                ?.trim()
                .orEmpty()

            if (waitingForCommand) {
                waitingForCommand = false
                handleCommand(text)
            } else if (text.contains(WAKE_WORD)) {
                // «привет крок поставь таймер» — команда в той же фразе
                val command = text.substringAfter(WAKE_WORD).trim()
                if (command.isNotEmpty()) {
                    handleCommand(command)
                } else {
                    waitingForCommand = true
                    face.setState(KrokState.LISTENING)
                    listen()
                }
            } else {
                listen() // слова пробуждения не было, слушаем дальше
            }
        }

        override fun onError(error: Int) {
            if (waitingForCommand) {
                waitingForCommand = false
                face.setState(KrokState.CONFUSED)
                say("Не расслышал")
                handler.postDelayed({ face.setState(KrokState.IDLE) }, 2000)
            }
            handler.postDelayed({ listen() }, if (waitingForCommand) 2500 else 400)
        }

        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    // ---------- Команды ----------

    /** Первая версия: Крок слышит команду и повторяет её. Действия добавляются сюда. */
    private fun handleCommand(command: String) {
        face.setState(KrokState.THINKING)
        handler.postDelayed({
            face.setState(KrokState.DONE)
            say("Я услышал: $command")
            handler.postDelayed({ face.setState(KrokState.IDLE) }, 2500)
            handler.postDelayed({ listen() }, 3500) // ждём, пока Крок договорит
        }, 600)
    }

    private fun say(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "krok")
    }

    // ---------- Фоновая служба ----------

    private fun startAsForeground() {
        val channelId = "krok"
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(channelId, "Крок", NotificationManager.IMPORTANCE_LOW)
        )
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("Крок слушает")
            .setContentText("Скажите: «Привет, Крок»")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        tts?.shutdown()
        if (::face.isInitialized) windowManager.removeView(face)
        super.onDestroy()
    }

    companion object {
        private const val WAKE_WORD = "привет крок"
    }
}
