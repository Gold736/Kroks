package com.example.krok

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

enum class KrokState(val color: Int) {
    IDLE(0xFF2196F3.toInt()),      // покой: синий
    LISTENING(0xFF4CAF50.toInt()), // слушает: зелёный
    THINKING(0xFFFFC107.toInt()),  // думает: жёлтый
    DONE(0xFFFF9800.toInt()),      // выполнил команду: оранжевый
    CONFUSED(0xFF2196F3.toInt())   // не расслышал: синий, удивлённое лицо
}

class KrokView(context: Context) : View(context) {

    private val body = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val ink = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 8f
        strokeCap = Paint.Cap.ROUND
    }

    private var currentColor = KrokState.IDLE.color
    private var state = KrokState.IDLE

    /** Плавно меняет цвет и выражение лица. */
    fun setState(newState: KrokState) {
        state = newState
        ValueAnimator.ofObject(ArgbEvaluator(), currentColor, newState.color).apply {
            duration = 400
            addUpdateListener {
                currentColor = it.animatedValue as Int
                invalidate()
            }
            start()
        }
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()

        // Круглое тело
        body.color = currentColor
        canvas.drawCircle(w / 2, h / 2, minOf(w, h) / 2, body)

        // Глаза
        val eyeR = when (state) {
            KrokState.LISTENING -> w * 0.09f
            KrokState.CONFUSED -> w * 0.10f
            else -> w * 0.06f
        }
        val eyeShift = if (state == KrokState.THINKING) -h * 0.04f else 0f
        canvas.drawCircle(w * 0.30f, h * 0.40f + eyeShift, eyeR, fill)
        canvas.drawCircle(w * 0.70f, h * 0.40f + eyeShift, eyeR, fill)

        // Рот
        val mouth = RectF(w * 0.30f, h * 0.50f, w * 0.70f, h * 0.80f)
        when (state) {
            KrokState.IDLE -> canvas.drawArc(mouth, 20f, 140f, false, ink)
            KrokState.LISTENING -> canvas.drawLine(w * 0.40f, h * 0.70f, w * 0.60f, h * 0.70f, ink)
            KrokState.THINKING -> canvas.drawLine(w * 0.40f, h * 0.70f, w * 0.60f, h * 0.67f, ink)
            KrokState.DONE -> canvas.drawArc(mouth, 0f, 180f, true, fill)
            KrokState.CONFUSED -> canvas.drawCircle(w / 2, h * 0.72f, w * 0.07f, fill)
        }
    }
}
